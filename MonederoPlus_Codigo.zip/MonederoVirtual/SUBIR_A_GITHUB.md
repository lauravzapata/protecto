# Publicar Monedero Plus en GitHub

La carpeta ya contiene un repositorio Git local en la rama `main` y un commit con el proyecto. Para publicarlo en tu cuenta necesitas crear un repositorio vacío en GitHub y conectarlo con esta carpeta.

## Opción recomendada: GitHub Desktop

1. Descomprime `MonederoPlus_GitHub.zip`.
2. Abre GitHub Desktop e inicia sesión en tu cuenta.
3. Selecciona **File > Add local repository** y elige la carpeta `MonederoVirtual`.
4. Selecciona **Publish repository**.
5. Usa `MonederoPlus` como nombre del repositorio.
6. Elige si quieres que sea público o privado y confirma la publicación.

## Opción con terminal

1. En GitHub crea un repositorio vacío llamado `MonederoPlus`. No agregues README, licencia ni `.gitignore` porque ya están en el proyecto.
2. Abre una terminal dentro de la carpeta `MonederoVirtual`.
3. Ejecuta estos comandos, reemplazando `TU_USUARIO` por tu usuario de GitHub:

```bash
git remote add origin https://github.com/TU_USUARIO/MonederoPlus.git
git push -u origin main
```

No compartas contraseñas ni tokens. GitHub te pedirá autenticarte mediante el método seguro configurado en tu equipo.
