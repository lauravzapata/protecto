# Monedero Plus — Simulador de monedero virtual con sistema de puntos

Proyecto final de Programación 1 — Universidad del Quindío.

## Descripción

Aplicación de escritorio desarrollada en Java y JavaFX para administrar clientes, varios monederos por cliente, depósitos, retiros, transferencias, historial, puntos, rangos, beneficios, movimientos programados, reportes de gastos y alertas por movimientos atípicos.

## Tecnologías y conceptos

- Java 17 o superior.
- JavaFX 21 para la interfaz gráfica.
- Maven para dependencias y ejecución.
- `ArrayList`, `List`, `Optional`, `Stream API`, expresiones lambda y ordenamientos.
- Programación orientada a objetos: encapsulamiento, abstracción, herencia, polimorfismo e interfaz.
- Tres excepciones personalizadas para reglas del sistema.
- JUnit 5 para pruebas automatizadas.

La organización del código sigue el estilo de los ejercicios del repositorio de clase: paquetes `app`, `model`, `exception` e `interfaces`; clases con atributos privados, constructores, getters, métodos de lógica, listas y búsquedas con `stream().filter(...).findFirst()`.

## Cómo ejecutar

1. Instalar JDK 17 o superior y Maven.
2. Abrir la carpeta del proyecto en IntelliJ IDEA como proyecto Maven.
3. Esperar a que Maven descargue JavaFX y JUnit.
4. Ejecutar la clase `co.edu.uniquindio.poo.app.Main`, o desde una terminal ubicada en esta carpeta ejecutar:

   ```bash
   mvn clean javafx:run
   ```

5. Para ejecutar las pruebas:

   ```bash
   mvn test
   ```

## Datos de demostración

Al iniciar se cargan dos clientes de ejemplo (`1001` y `1002`) y tres monederos con saldos iniciales. Esto permite probar de inmediato consultas, transferencias, historial, puntos y reportes. Los datos viven en memoria: al cerrar la aplicación se reinician.

## Funcionalidades

| Módulo | Funciones |
|---|---|
| Clientes | Registro, validación de documento duplicado, consulta |
| Monederos | Creación de varios monederos por cliente, tipo ahorros o gastos diarios |
| Movimientos | Depósitos, retiros, transferencias, historial y reversión |
| Puntos | Acumulación por cada 100 unidades, historial, rangos y canje de beneficios |
| Programadas | Depósitos y transferencias con ejecución única, semanal o mensual; procesamiento por fecha |
| Reportes | Total de gastos, promedio, agrupación por tipo y detección de movimientos atípicos |
| Alertas | Saldo bajo, movimientos realizados, transferencias recibidas, transacciones programadas y transacciones atípicas |

## Reglas implementadas

- Depósito: 1 punto por cada 100 unidades completas depositadas.
- Retiro: 2 puntos por cada 100 unidades completas retiradas.
- Transferencia: 3 puntos por cada 100 unidades completas transferidas.
- Rangos: Bronce (0–500), Plata (501–1000), Oro (1001–5000) y Platino (más de 5000).
- Beneficios: 100 puntos para reducción del 10% en comisión de transferencias; 500 puntos para un mes sin cargos por retiros; 1000 puntos para un bono de 50 unidades.
- El bono de 50 se aplica desde el botón correspondiente, seleccionando el monedero del cliente.
- Una transacción revertida deja de aportar puntos. Los puntos disponibles se calculan dinámicamente a partir de los movimientos activos.
- Una reversión se rechaza si el dinero ya no está disponible para deshacer el depósito o la transferencia, o si los puntos generados por esa operación ya fueron utilizados.
- Se genera una alerta de saldo bajo cuando el saldo de un monedero queda por debajo de 10.000 unidades. Este umbral se usa como regla de demostración y está centralizado en `SistemaMonedero`.

**Alcance de los beneficios:** el enunciado no define el valor de las comisiones ni de los cargos. Por eso el sistema registra el canje de los beneficios de reducción de comisión y retiros sin cargos, pero no inventa tarifas para calcularlos. El bono de 50 sí se acredita directamente al monedero seleccionado.

**Notificaciones:** las alertas se guardan y consultan dentro de la aplicación. No se envían mensajes reales por WhatsApp, Gmail o SMS, porque el enunciado los menciona como ejemplos, pero no entrega credenciales ni un servicio de mensajería.

## Detección de transacciones atípicas

Cada vez que se registra un movimiento, se compara con los movimientos anteriores del cliente (se requieren al menos dos). Se calcula el promedio de los montos anteriores y la desviación estándar poblacional. Se marca como potencialmente sospechosa una transacción nueva cuyo monto sea mayor que:

`promedio + 2 * desviación estándar`

El cálculo recorre el historial un número constante de veces, por lo que su complejidad temporal es **O(n)**, donde `n` es el número de transacciones del cliente. La lista filtrada ocupa **O(n)** espacio adicional. La alerta se genera automáticamente, se almacena en las notificaciones del cliente y la transacción queda marcada. El botón de detección permite consultar después las operaciones marcadas.

## Estructura principal

```text
co.edu.uniquindio.poo
├── app
│   └── Main.java
├── exception
│   ├── ClienteNoEncontradoException.java
│   ├── DatosInvalidosException.java
│   └── SaldoInsuficienteException.java
├── interfaces
│   └── INotificable.java
└── model
    ├── Beneficio.java
    ├── Cliente.java
    ├── Deposito.java
    ├── Frecuencia.java
    ├── Monedero.java
    ├── MovimientoPuntos.java
    ├── Retiro.java
    ├── SistemaMonedero.java
    ├── TipoMonedero.java
    ├── Transferencia.java
    ├── Transaccion.java
    └── TransaccionProgramada.java
```

## Informe

El informe del proyecto está en `docs/Informe_Final.md`.
