package co.edu.uniquindio.poo.app;

import co.edu.uniquindio.poo.exception.ClienteNoEncontradoException;
import co.edu.uniquindio.poo.exception.DatosInvalidosException;
import co.edu.uniquindio.poo.exception.SaldoInsuficienteException;
import co.edu.uniquindio.poo.model.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class Main extends Application {
    private final SistemaMonedero sistema = new SistemaMonedero();
    private TextArea areaResultado;
    private Label resumenClientes;
    private Label resumenMonederos;
    private Label resumenSaldo;
    private Label resumenPuntos;

    @Override
    public void start(Stage stage) {
        cargarDatosDeEjemplo();
        BorderPane raiz = new BorderPane();
        raiz.setStyle("-fx-background-color: #F4F6FB;");
        raiz.setTop(crearEncabezado());
        raiz.setCenter(crearContenido());
        raiz.setBottom(crearConsola());

        Scene escena = new Scene(raiz, 1120, 760);
        escena.getStylesheets().add(getClass().getResource("/estilos.css").toExternalForm());
        stage.setTitle("Monedero Plus | Sistema de puntos");
        stage.setMinWidth(950);
        stage.setMinHeight(680);
        stage.setScene(escena);
        stage.show();
        actualizarResumen();
        escribir("Bienvenida al sistema. Se cargaron dos clientes de ejemplo para facilitar las pruebas.");
    }

    private VBox crearEncabezado() {
        VBox encabezado = new VBox(6);
        encabezado.setPadding(new Insets(24, 30, 18, 30));
        encabezado.setStyle("-fx-background-color: linear-gradient(to right, #202A44, #394B75);");
        Label titulo = new Label("MONEDERO PLUS");
        titulo.setTextFill(Color.WHITE);
        titulo.setFont(Font.font("System", 25));
        titulo.setStyle("-fx-font-weight: bold;");
        Label subtitulo = new Label("Tu dinero, tus metas y tus beneficios en un solo lugar");
        subtitulo.setTextFill(Color.web("#DCE4F5"));
        subtitulo.setFont(Font.font(13));
        encabezado.getChildren().addAll(titulo, subtitulo);
        return encabezado;
    }

    private VBox crearContenido() {
        VBox contenedor = new VBox(16);
        contenedor.setPadding(new Insets(20, 25, 12, 25));
        HBox tarjetas = new HBox(12);
        tarjetas.getChildren().addAll(
                crearTarjeta("CLIENTES", "0", "#E8EEFF"),
                crearTarjeta("MONEDEROS", "0", "#E6F6F1"),
                crearTarjeta("SALDO ADMINISTRADO", "$0", "#FFF2E2"),
                crearTarjeta("PUNTOS ACUMULADOS", "0", "#F4EAFE"));
        resumenClientes = (Label) ((VBox) tarjetas.getChildren().get(0)).getChildren().get(1);
        resumenMonederos = (Label) ((VBox) tarjetas.getChildren().get(1)).getChildren().get(1);
        resumenSaldo = (Label) ((VBox) tarjetas.getChildren().get(2)).getChildren().get(1);
        resumenPuntos = (Label) ((VBox) tarjetas.getChildren().get(3)).getChildren().get(1);
        for (Node nodo : tarjetas.getChildren()) HBox.setHgrow(nodo, Priority.ALWAYS);

        TabPane pestañas = new TabPane();
        pestañas.getTabs().addAll(
                crearPestaña("Clientes", crearBoton("Registrar cliente", this::registrarCliente), crearBoton("Ver clientes", this::listarClientes)),
                crearPestaña("Monederos", crearBoton("Crear monedero", this::crearMonedero), crearBoton("Ver monederos", this::listarMonederos)),
                crearPestaña("Movimientos", crearBoton("Depositar", this::depositar), crearBoton("Retirar", this::retirar),
                        crearBoton("Transferir", this::transferir), crearBoton("Consultar historial", this::consultarHistorial),
                        crearBoton("Revertir transacción", this::revertir)),
                crearPestaña("Puntos y rangos", crearBoton("Consultar puntos y rango", this::consultarPuntos),
                        crearBoton("Canjear beneficio", this::canjearBeneficio), crearBoton("Ver beneficios canjeados", this::verBeneficios),
                        crearBoton("Aplicar bono de $50", this::aplicarBono), crearBoton("Ver movimientos de puntos", this::verMovimientosPuntos)),
                crearPestaña("Programadas", crearBoton("Programar movimiento", this::programar),
                        crearBoton("Procesar las pendientes", this::procesarProgramadas), crearBoton("Ver programadas", this::listarProgramadas)),
                crearPestaña("Reportes y alertas", crearBoton("Reporte de gastos", this::reporteGastos),
                        crearBoton("Detectar transacciones atípicas", this::detectarAtipicas),
                        crearBoton("Ver notificaciones", this::verNotificaciones), crearBoton("Ver todas las transacciones", this::listarTransacciones))
        );
        VBox.setVgrow(pestañas, Priority.ALWAYS);
        contenedor.getChildren().addAll(tarjetas, pestañas);
        return contenedor;
    }

    private VBox crearTarjeta(String titulo, String valor, String fondo) {
        VBox tarjeta = new VBox(8);
        tarjeta.setPadding(new Insets(14));
        tarjeta.setStyle("-fx-background-color: " + fondo + "; -fx-background-radius: 12;");
        Label texto = new Label(titulo);
        texto.setStyle("-fx-text-fill: #59647A; -fx-font-size: 10px; -fx-font-weight: bold;");
        Label numero = new Label(valor);
        numero.setStyle("-fx-text-fill: #202A44; -fx-font-size: 21px; -fx-font-weight: bold;");
        tarjeta.getChildren().addAll(texto, numero);
        return tarjeta;
    }

    private Tab crearPestaña(String nombre, Button... botones) {
        VBox caja = new VBox(12);
        caja.setPadding(new Insets(22));
        Label ayuda = new Label("Selecciona una operación para continuar.");
        ayuda.setStyle("-fx-text-fill: #69758B; -fx-font-size: 13px;");
        FlowPane acciones = new FlowPane(10, 10);
        acciones.getChildren().addAll(botones);
        caja.getChildren().addAll(ayuda, acciones);
        Tab tab = new Tab(nombre, caja);
        tab.setClosable(false);
        return tab;
    }

    private Button crearBoton(String texto, Accion accion) {
        Button boton = new Button(texto);
        boton.setOnAction(e -> ejecutar(accion));
        boton.setStyle("-fx-background-color: #35466D; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 16 10 16; -fx-background-radius: 8; -fx-cursor: hand;");
        return boton;
    }

    private VBox crearConsola() {
        VBox caja = new VBox(7);
        caja.setPadding(new Insets(8, 25, 20, 25));
        Label titulo = new Label("RESULTADOS Y MENSAJES");
        titulo.setStyle("-fx-text-fill: #35466D; -fx-font-size: 11px; -fx-font-weight: bold;");
        areaResultado = new TextArea();
        areaResultado.setEditable(false);
        areaResultado.setWrapText(true);
        areaResultado.setPrefRowCount(5);
        areaResultado.setStyle("-fx-control-inner-background: #FFFFFF; -fx-background-radius: 8; -fx-border-radius: 8; -fx-border-color: #DCE2ED;");
        caja.getChildren().addAll(titulo, areaResultado);
        return caja;
    }

    private void ejecutar(Accion accion) {
        try {
            accion.ejecutar();
            actualizarResumen();
        } catch (Exception e) {
            mostrarError(e.getMessage() == null ? "Ocurrió un error inesperado." : e.getMessage());
        }
    }

    private void registrarCliente() {
        String documento = pedirTexto("Registrar cliente", "Documento:");
        if (documento == null) return;
        String nombre = pedirTexto("Registrar cliente", "Nombre completo:");
        if (nombre == null) return;
        String correo = pedirTexto("Registrar cliente", "Correo electrónico:");
        if (correo == null) return;
        try {
            escribir(sistema.registrarCliente(documento, nombre, correo));
        } catch (DatosInvalidosException e) { mostrarError(e.getMessage()); }
    }

    private void listarClientes() {
        if (sistema.getClientes().isEmpty()) { escribir("No hay clientes registrados."); return; }
        escribir("CLIENTES REGISTRADOS\n" + String.join("\n", sistema.getClientes().stream().map(Cliente::toString).toList()));
    }

    private void crearMonedero() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el propietario");
        if (cliente == null) return;
        String nombre = pedirTexto("Crear monedero", "Nombre (por ejemplo: Ahorros o Gastos):");
        if (nombre == null) return;
        TipoMonedero tipo = elegir("Tipo de monedero", List.of(TipoMonedero.values()));
        if (tipo == null) return;
        Monedero monedero = sistema.crearMonedero(cliente.getDocumento(), nombre, tipo);
        escribir("Monedero creado correctamente:\n" + monedero);
    }

    private void listarMonederos() {
        StringBuilder texto = new StringBuilder("MONEDEROS REGISTRADOS\n");
        for (Cliente cliente : sistema.getClientes()) {
            texto.append("\nCliente: ").append(cliente.getNombre()).append("\n");
            for (Monedero monedero : cliente.getMonederos()) texto.append("  ").append(monedero).append("\n");
        }
        escribir(texto.toString());
    }

    private void depositar() throws Exception {
        Cliente cliente = elegirCliente("Cliente que realiza el depósito");
        if (cliente == null) return;
        Monedero monedero = elegirMonedero(cliente);
        if (monedero == null) return;
        Double monto = pedirMonto("Valor del depósito:");
        if (monto == null) return;
        Deposito deposito = sistema.depositar(cliente.getDocumento(), monedero.getCodigo(), monto);
        escribir("Depósito exitoso.\n" + deposito + "\nNuevo saldo: $" + formato(monedero.getSaldo()));
    }

    private void retirar() throws Exception {
        Cliente cliente = elegirCliente("Cliente que realiza el retiro");
        if (cliente == null) return;
        Monedero monedero = elegirMonedero(cliente);
        if (monedero == null) return;
        Double monto = pedirMonto("Valor del retiro:");
        if (monto == null) return;
        Retiro retiro = sistema.retirar(cliente.getDocumento(), monedero.getCodigo(), monto);
        escribir("Retiro exitoso.\n" + retiro + "\nNuevo saldo: $" + formato(monedero.getSaldo()));
    }

    private void transferir() throws Exception {
        Cliente origen = elegirCliente("Cliente que envía el dinero");
        if (origen == null) return;
        Monedero monederoOrigen = elegirMonedero(origen);
        if (monederoOrigen == null) return;
        Cliente destino = elegirCliente("Cliente que recibe el dinero");
        if (destino == null) return;
        Monedero monederoDestino = elegirMonedero(destino);
        if (monederoDestino == null) return;
        Double monto = pedirMonto("Valor de la transferencia:");
        if (monto == null) return;
        Transferencia transferencia = sistema.transferir(origen.getDocumento(), monederoOrigen.getCodigo(),
                destino.getDocumento(), monederoDestino.getCodigo(), monto);
        escribir("Transferencia exitosa.\n" + transferencia + "\nSaldo origen: $" + formato(monederoOrigen.getSaldo())
                + "\nSaldo destino: $" + formato(monederoDestino.getSaldo()));
    }

    private void consultarHistorial() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        List<Transaccion> historial = sistema.historialCliente(cliente.getDocumento());
        escribir("HISTORIAL DE " + cliente.getNombre().toUpperCase() + "\n" + (historial.isEmpty() ? "Sin movimientos." : String.join("\n", historial.stream().map(Transaccion::toString).toList())));
    }

    private void revertir() throws Exception {
        String codigo = pedirTexto("Revertir transacción", "Código de la transacción:");
        if (codigo == null) return;
        sistema.revertirTransaccion(codigo);
        escribir("La transacción " + codigo + " fue revertida. El saldo y los puntos fueron actualizados.");
    }

    private void consultarPuntos() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        escribir("PUNTOS Y RANGO\nCliente: " + cliente.getNombre() + "\nPuntos disponibles: " + cliente.getPuntos()
                + "\nRango: " + cliente.getRango() + "\nSaldo total: $" + formato(cliente.getSaldoTotal()));
    }

    private void canjearBeneficio() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        ChoiceDialog<String> dialogo = new ChoiceDialog<>("100 puntos - 10% de reducción en comisión de transferencias",
                List.of("100 puntos - 10% de reducción en comisión de transferencias",
                        "500 puntos - Un mes sin cargos por retiros", "1000 puntos - Bono de saldo de $50"));
        dialogo.setTitle("Canjear puntos");
        dialogo.setHeaderText("Puntos disponibles: " + cliente.getPuntos());
        dialogo.setContentText("Seleccione el beneficio:");
        Optional<String> seleccion = dialogo.showAndWait();
        if (seleccion.isEmpty()) return;
        int opcion = seleccion.get().startsWith("100 puntos") ? 1 : seleccion.get().startsWith("500 puntos") ? 2 : 3;
        escribir(sistema.canjearBeneficio(cliente.getDocumento(), opcion));
    }


    private void verBeneficios() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        escribir("BENEFICIOS DE " + cliente.getNombre().toUpperCase() + "\n"
                + (cliente.getBeneficiosCanjeados().isEmpty() ? "No hay beneficios canjeados."
                : String.join("\n", cliente.getBeneficiosCanjeados().stream().map(Beneficio::toString).toList())));
    }

    private void aplicarBono() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        Monedero monedero = elegirMonedero(cliente);
        if (monedero == null) return;
        sistema.aplicarBono(cliente.getDocumento(), monedero.getCodigo());
        escribir("Bono de $50 aplicado a " + monedero.getNombre() + ". Nuevo saldo: $" + formato(monedero.getSaldo()));
    }

    private void verMovimientosPuntos() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        String contenido = cliente.getMovimientosPuntos().stream()
                .map(m -> m.getFecha() + " | " + m.getDescripcion() + " | " + (m.getPuntos() > 0 ? "+" : "")
                        + m.getPuntos() + " puntos | " + (m.isActivo() ? "Activo" : "Anulado"))
                .reduce((a, b) -> a + "\n" + b).orElse("No hay movimientos de puntos.");
        escribir("HISTORIAL DE PUNTOS\n" + contenido + "\nTotal disponible: " + cliente.getPuntos());
    }

    private void programar() throws Exception {
        Cliente cliente = elegirCliente("Cliente que programa el movimiento");
        if (cliente == null) return;
        Monedero origen = elegirMonedero(cliente);
        if (origen == null) return;
        String tipo = elegir("Tipo de movimiento", List.of("Depósito", "Transferencia"));
        if (tipo == null) return;
        Cliente receptor = null;
        Monedero destino = null;
        if (tipo.equals("Transferencia")) {
            receptor = elegirCliente("Cliente receptor");
            if (receptor == null) return;
            destino = elegirMonedero(receptor);
            if (destino == null) return;
        }
        Double monto = pedirMonto("Monto a programar:");
        if (monto == null) return;
        String fechaTexto = pedirTexto("Fecha de ejecución", "Ingrese la fecha (AAAA-MM-DD):");
        if (fechaTexto == null) return;
        LocalDate fecha = LocalDate.parse(fechaTexto.trim());
        Frecuencia frecuencia = elegir("Frecuencia", List.of(Frecuencia.values()));
        if (frecuencia == null) return;
        TransaccionProgramada programada = sistema.programar(cliente.getDocumento(), origen.getCodigo(), tipo,
                receptor == null ? null : receptor.getDocumento(), destino == null ? null : destino.getCodigo(), monto, fecha, frecuencia);
        escribir("Movimiento programado:\n" + programada);
    }

    private void procesarProgramadas() {
        List<String> resultados = sistema.procesarProgramadas();
        escribir(resultados.isEmpty() ? "No hay movimientos programados pendientes para hoy." : String.join("\n", resultados));
    }

    private void listarProgramadas() {
        escribir("TRANSACCIONES PROGRAMADAS\n" + (sistema.getProgramadas().isEmpty() ? "No hay movimientos programados."
                : String.join("\n", sistema.getProgramadas().stream().map(TransaccionProgramada::toString).toList())));
    }

    private void reporteGastos() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        escribir(sistema.generarReporteGastos(cliente.getDocumento()) + "\nPromedio por movimiento: $"
                + formato(sistema.calcularPromedioGastos(cliente.getDocumento())));
    }

    private void detectarAtipicas() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        List<Transaccion> atipicas = sistema.detectarAtipicas(cliente.getDocumento());
        escribir("ANÁLISIS DE TRANSACCIONES\nCriterio: monto > promedio + 2 × desviación estándar.\n"
                + (atipicas.isEmpty() ? "No se encontraron transacciones atípicas con el historial actual."
                : "Movimientos que requieren revisión:\n" + String.join("\n", atipicas.stream().map(Transaccion::toString).toList())));
    }

    private void verNotificaciones() throws Exception {
        Cliente cliente = elegirCliente("Seleccione el cliente");
        if (cliente == null) return;
        escribir("NOTIFICACIONES DE " + cliente.getNombre().toUpperCase() + "\n"
                + (cliente.getNotificaciones().isEmpty() ? "No hay notificaciones."
                : String.join("\n", cliente.getNotificaciones())));
    }

    private void listarTransacciones() {
        escribir("TODAS LAS TRANSACCIONES\n" + (sistema.getTransacciones().isEmpty() ? "No hay transacciones."
                : String.join("\n", sistema.getTransacciones().stream().map(Transaccion::toString).toList())));
    }

    private Cliente elegirCliente(String titulo) {
        if (sistema.getClientes().isEmpty()) { mostrarError("Primero debe registrar un cliente."); return null; }
        return elegir(titulo, sistema.getClientes());
    }

    private Monedero elegirMonedero(Cliente cliente) {
        if (cliente.getMonederos().isEmpty()) { mostrarError("El cliente todavía no tiene monederos."); return null; }
        return elegir("Seleccione el monedero", cliente.getMonederos());
    }

    private <T> T elegir(String titulo, List<T> opciones) {
        if (opciones == null || opciones.isEmpty()) return null;
        ChoiceDialog<T> dialogo = new ChoiceDialog<>(opciones.get(0), opciones);
        dialogo.setTitle(titulo);
        dialogo.setHeaderText(titulo);
        dialogo.setContentText("Seleccione:");
        return dialogo.showAndWait().orElse(null);
    }

    private String pedirTexto(String titulo, String pregunta) {
        TextInputDialog dialogo = new TextInputDialog();
        dialogo.setTitle(titulo);
        dialogo.setHeaderText(titulo);
        dialogo.setContentText(pregunta);
        return dialogo.showAndWait().orElse(null);
    }

    private Double pedirMonto(String pregunta) {
        String texto = pedirTexto("Ingresar monto", pregunta);
        if (texto == null) return null;
        try { return Double.parseDouble(texto.trim().replace(",", ".")); }
        catch (NumberFormatException e) { mostrarError("Ingrese un monto numérico válido."); return null; }
    }

    private void cargarDatosDeEjemplo() {
        try {
            sistema.registrarCliente("1001", "Laura Gómez", "laura@email.com");
            sistema.registrarCliente("1002", "Daniel Ruiz", "daniel@email.com");
            sistema.crearMonedero("1001", "Ahorros", TipoMonedero.AHORROS);
            sistema.crearMonedero("1001", "Gastos diarios", TipoMonedero.GASTOS_DIARIOS);
            sistema.crearMonedero("1002", "Ahorros", TipoMonedero.AHORROS);
            sistema.depositar("1001", "MON-1", 150000);
            sistema.depositar("1001", "MON-2", 80000);
            sistema.depositar("1002", "MON-3", 50000);
        } catch (Exception e) { System.err.println(e.getMessage()); }
    }

    private void actualizarResumen() {
        if (resumenClientes == null) return;
        int cantidadMonederos = sistema.getClientes().stream().mapToInt(c -> c.getMonederos().size()).sum();
        double saldo = sistema.getClientes().stream().mapToDouble(Cliente::getSaldoTotal).sum();
        int puntos = sistema.getClientes().stream().mapToInt(Cliente::getPuntos).sum();
        resumenClientes.setText(String.valueOf(sistema.getClientes().size()));
        resumenMonederos.setText(String.valueOf(cantidadMonederos));
        resumenSaldo.setText("$" + formato(saldo));
        resumenPuntos.setText(String.valueOf(puntos));
    }

    private void escribir(String texto) {
        areaResultado.setText(texto);
    }

    private void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("No se pudo completar la operación");
        alerta.setHeaderText("Revisa la información ingresada");
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private String formato(double valor) { return String.format("%,.2f", valor); }

    @FunctionalInterface
    private interface Accion { void ejecutar() throws Exception; }

    public static void main(String[] args) { launch(args); }
}
