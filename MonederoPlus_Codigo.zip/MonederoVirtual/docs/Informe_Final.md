# Informe final — Monedero Plus

## 1. Introducción

Monedero Plus es un simulador de monedero virtual que permite administrar clientes y sus monederos, realizar movimientos de dinero, consultar historiales, acumular y canjear puntos, programar movimientos y generar reportes. El proyecto se desarrolló aplicando los conceptos de programación orientada a objetos y las herramientas de Java trabajadas durante el curso.

## 2. Pensamiento computacional

### 2.1 Abstracción

Se identificaron los elementos necesarios del problema y se representaron mediante clases. Los elementos principales son `Cliente`, `Monedero`, `Transaccion`, `MovimientoPuntos`, `Beneficio` y `TransaccionProgramada`. Se dejaron por fuera aspectos que no son necesarios para simular las operaciones, como la conexión con bancos reales o el almacenamiento en una base de datos.

### 2.2 Descomposición

El problema se dividió en módulos para facilitar su desarrollo:

- Clientes: registrar y buscar clientes.
- Monederos: crear y consultar los monederos de cada cliente.
- Movimientos: depósitos, retiros, transferencias, consulta y reversión.
- Puntos: calcular puntos, consultar rangos y canjear beneficios.
- Programación: guardar movimientos futuros y procesarlos por fecha.
- Reportes y alertas: analizar gastos, identificar movimientos atípicos y mostrar notificaciones.
- Interfaz: presentar las operaciones mediante ventanas, pestañas, botones y cuadros de diálogo de JavaFX.

### 2.3 Reconocimiento de patrones

Se reconoció que depósitos, retiros y transferencias comparten información: código, fecha, monto y cliente. Por eso se creó la clase abstracta `Transaccion`. También se observó que cada cliente puede tener varios monederos y varios movimientos, por lo que se utilizaron listas para almacenar esas relaciones. Las búsquedas por documento y código siguen el patrón de filtrar una colección y obtener el primer resultado.

### 2.4 Codificación

La solución se implementó en Java, separando la interfaz y la lógica del sistema. Se usaron clases, listas, métodos, condicionales, ciclos, expresiones lambda, Stream API, excepciones personalizadas y controles de JavaFX. Las reglas principales se centralizaron en `SistemaMonedero` para evitar repetir validaciones y operaciones.

## 3. Diseño orientado a objetos

### 3.1 Abstracción

`Transaccion` es una clase abstracta porque representa la idea general de un movimiento, pero no se crea directamente. Sus clases hijas son `Deposito`, `Retiro` y `Transferencia`, cada una con los datos específicos que necesita.

### 3.2 Encapsulamiento

Los atributos de las clases se declaran privados. El acceso se realiza por medio de métodos públicos como getters y setters cuando se requiere modificar un dato. Las operaciones que cambian los saldos se realizan desde la lógica del sistema, para aplicar las validaciones antes de modificar el dinero.

### 3.3 Herencia

`Deposito`, `Retiro` y `Transferencia` heredan de `Transaccion`. De esta manera reutilizan los atributos y métodos comunes, como código, fecha, monto, cliente y estado.

### 3.4 Polimorfismo

Las clases hijas sobrescriben los métodos abstractos `getTipo()` y `getDetalle()`. El sistema puede manejar una colección de objetos `Transaccion` y llamar `toString()` o esos métodos sin necesitar tratar cada tipo como una estructura completamente diferente.

### 3.5 Interfaces

La interfaz `INotificable` define el comportamiento `recibirNotificacion`. La clase `Cliente` implementa este contrato y almacena las notificaciones que recibe.

## 4. Estructuras de datos y programación declarativa

- `ArrayList<Cliente>` almacena los clientes.
- Cada cliente tiene un `ArrayList` de monederos, movimientos de puntos, beneficios y notificaciones.
- Cada monedero almacena el historial de transacciones.
- `Optional<Cliente>` representa una búsqueda que puede no encontrar resultados.
- `stream().filter(...).findFirst()` se usa para buscar clientes y monederos.
- `stream().mapToDouble(...).sum()` calcula saldos y totales.
- `stream().sorted(...)` ordena las transacciones programadas por fecha.
- `Collectors.groupingBy(...)` agrupa los gastos por tipo.
- Las expresiones lambda se usan en filtros, cálculos, búsquedas y ordenamientos.

## 5. Excepciones y validaciones

Se implementaron tres excepciones personalizadas:

1. `DatosInvalidosException`: datos vacíos, correo no válido, documento repetido, monto no positivo, fecha anterior a hoy o selección inválida.
2. `ClienteNoEncontradoException`: se intenta realizar una operación con un documento que no está registrado.
3. `SaldoInsuficienteException`: un retiro o transferencia supera el saldo disponible, o una reversión no puede recuperar el dinero necesario.

También se valida que el monto sea mayor que cero, que los monederos origen y destino sean diferentes y que una transacción no se revierta dos veces.

## 6. Sistema de puntos y rangos

Los puntos se calculan por cada 100 unidades completas: 1 punto por depósito, 2 por retiro y 3 por transferencia. El rango depende del total de puntos activos: Bronce de 0 a 500, Plata de 501 a 1000, Oro de 1001 a 5000 y Platino por encima de 5000.

Cada acumulación o canje se registra en `MovimientoPuntos`. Cuando se revierte una transacción, su movimiento de puntos se marca como inactivo. El método `getPuntos()` suma únicamente los movimientos activos, por lo que el total se actualiza sin modificar manualmente los puntos anteriores. Como validación, no se permite revertir una operación si sus puntos asociados ya fueron utilizados en un canje.

## 7. Transacciones programadas

Se pueden programar depósitos y transferencias para una fecha determinada. La frecuencia puede ser única, semanal o mensual. Para procesarlas se filtran las que están activas y cuya fecha ya llegó; luego se ordenan por fecha con `sorted`. El sistema ejecuta cada movimiento, guarda una notificación de éxito o fallo y actualiza su siguiente fecha cuando es recurrente.

Complejidad del ordenamiento: **O(p log p)** para `p` movimientos programados pendientes. El recorrido posterior es O(p), sin contar el costo interno de cada movimiento.

## 8. Análisis de patrones y detección de transacciones atípicas

Cada vez que se registra una operación, se toman los montos de las transacciones activas anteriores del cliente (se requieren al menos dos). Se calcula el promedio y después la desviación estándar poblacional. El límite se obtiene con:

`límite = promedio + 2 × desviación estándar`

La operación nueva se marca como atípica si su monto es superior al límite. La detección se ejecuta automáticamente al registrar la transacción y el sistema almacena una notificación para informar al cliente. La opción de la interfaz permite consultar las operaciones que quedaron marcadas.

**Complejidad temporal:** O(n). Se realizan recorridos lineales para obtener el promedio, la varianza y filtrar las transacciones que superan el límite. El espacio adicional es O(n) por la lista filtrada.

## 9. Interfaz gráfica

La aplicación se construyó con JavaFX. La ventana principal presenta pestañas para clientes, monederos, movimientos, puntos y rangos, transacciones programadas, reportes y alertas. Los formularios se realizan con cuadros de diálogo y los resultados se presentan en el área de mensajes.

## 10. Pruebas

Se incluyeron pruebas automatizadas en `SistemaMonederoTest` para comprobar:

| Prueba | Resultado esperado |
|---|---|
| Registrar un depósito | Aumenta el saldo y asigna los puntos correspondientes |
| Retirar más dinero del disponible | Lanza `SaldoInsuficienteException` |
| Transferir entre clientes | Disminuye el saldo origen y aumenta el destino |
| Revertir un depósito | Restaura el saldo y anula los puntos asociados |
| Registrar un documento repetido | Lanza `DatosInvalidosException` |
| Registrar un movimiento muy superior al historial | Se marca como atípico y genera una notificación automática |
| Programar un depósito para hoy | El depósito se procesa y aumenta el saldo |
| Canjear y aplicar el bono de saldo | Se descuentan 1000 puntos y se acreditan 50 unidades |
| Registrar un movimiento muy superior al historial | Se marca como atípico y genera una notificación automática |

Para ejecutarlas se utiliza `mvn test`.

## 11. Conclusión

El desarrollo permitió aplicar la programación orientada a objetos para representar los elementos del monedero y organizar las responsabilidades del sistema. También se utilizaron colecciones, búsquedas, expresiones lambda, Stream API, excepciones y JavaFX. La separación por módulos facilita comprender, probar y ampliar el proyecto.
