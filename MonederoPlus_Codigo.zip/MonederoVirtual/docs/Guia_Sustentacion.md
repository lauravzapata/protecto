# Guía sencilla para la sustentación — Monedero Plus

## 1. ¿Qué hace el proyecto?

Es un simulador de monedero virtual. Permite registrar clientes, crear varios monederos para cada uno, depositar, retirar, transferir dinero, revisar movimientos, acumular puntos, canjear beneficios y programar depósitos o transferencias. También genera reportes y alertas.

## 2. ¿Cómo está organizado?

- `app/Main.java`: muestra las ventanas, pestañas y botones de JavaFX. Desde aquí el usuario selecciona qué quiere hacer.
- `model`: contiene las clases que representan los elementos del problema.
- `model/SistemaMonedero.java`: contiene las reglas y operaciones principales del sistema.
- `exception`: contiene los errores personalizados para las reglas del negocio.
- `interfaces/INotificable.java`: define el comportamiento para recibir notificaciones.

## 3. Conceptos de POO que puedo explicar

**Abstracción:** `Transaccion` es abstracta porque representa una transacción general. No se crea una transacción genérica; se crean depósitos, retiros o transferencias.

**Encapsulamiento:** los atributos de las clases son privados y se accede a ellos mediante métodos. Por ejemplo, el saldo del monedero se modifica con métodos y las operaciones validan el dinero antes de cambiarlo.

**Herencia:** `Deposito`, `Retiro` y `Transferencia` heredan de `Transaccion`. Así comparten código, fecha, monto, cliente y estado.

**Polimorfismo:** las clases hijas implementan `getTipo()` y `getDetalle()` de manera diferente. El sistema puede guardar los tres tipos en una misma lista de `Transaccion`.

**Interfaz:** `Cliente` implementa `INotificable`, que exige el método `recibirNotificacion`.

## 4. ¿Cómo se calculan los puntos?

Se cuentan las unidades completas de 100:

- Depósito: 1 punto por cada 100.
- Retiro: 2 puntos por cada 100.
- Transferencia: 3 puntos por cada 100.

Ejemplo: si se depositan $1.000, se obtienen 10 puntos. Si se retiran $1.000, se obtienen 20 puntos.

Los rangos son Bronce (0–500), Plata (501–1000), Oro (1001–5000) y Platino (más de 5000).

## 5. ¿Cómo se detecta una transacción atípica?

Cuando se registra un movimiento, el sistema compara su monto con los movimientos anteriores del cliente. Necesita al menos dos movimientos anteriores. Calcula el promedio y la desviación estándar poblacional. Si el monto nuevo es mayor que `promedio + 2 × desviación estándar`, lo marca como sospechoso y agrega una notificación.

La complejidad temporal es O(n), porque se recorren los movimientos anteriores una cantidad constante de veces. `n` representa la cantidad de transacciones del historial del cliente.

## 6. ¿Qué son las excepciones personalizadas?

- `DatosInvalidosException`: se usa cuando un dato no cumple una regla, como un monto menor o igual a cero.
- `ClienteNoEncontradoException`: se usa cuando el documento no corresponde a un cliente registrado.
- `SaldoInsuficienteException`: se usa cuando no hay dinero suficiente para retirar, transferir o revertir una operación.

## 7. ¿Dónde se usa Stream API?

- Buscar un cliente: `stream().filter(...).findFirst()`.
- Sumar los saldos: `stream().mapToDouble(...).sum()`.
- Ordenar transacciones programadas: `stream().sorted(...)`.
- Agrupar gastos por tipo: `Collectors.groupingBy(...)`.

Las expresiones lambda son las condiciones o acciones cortas que se escriben dentro de esas operaciones, por ejemplo `c -> c.getDocumento().equalsIgnoreCase(documento)`.

## 8. Prueba rápida durante la sustentación

La aplicación inicia con datos de demostración:

- Cliente `1001`, con monederos `MON-1` (Ahorros) y `MON-2` (Gastos diarios).
- Cliente `1002`, con monedero `MON-3` (Ahorros).

Saldos iniciales: `MON-1` tiene $150.000, `MON-2` tiene $80.000 y `MON-3` tiene $50.000.

Se puede mostrar una transferencia de `MON-1` a `MON-3`, revisar los saldos y consultar el historial. También se puede registrar un cliente nuevo desde la pestaña Clientes.

## 9. Cosas importantes que debo decir con honestidad

- Es una simulación académica; no mueve dinero real ni se conecta con bancos.
- Los datos se guardan en memoria y se reinician al cerrar la aplicación.
- Las notificaciones se muestran dentro del sistema; no se envían por WhatsApp, Gmail ni SMS.
- El enunciado no define tarifas para comisiones. Por eso los beneficios de descuento de comisión y retiro sin cargos se registran como canjeados, pero no se calcula un descuento monetario. El bono de $50 sí se acredita al monedero seleccionado.
- Las transacciones programadas disponibles son depósitos y transferencias, con frecuencia única, semanal o mensual.
